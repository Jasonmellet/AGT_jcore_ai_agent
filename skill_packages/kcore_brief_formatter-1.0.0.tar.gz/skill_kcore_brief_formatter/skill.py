def format_brief(lines):
    return "\n".join(f"- {line.strip()}" for line in lines if line.strip())
