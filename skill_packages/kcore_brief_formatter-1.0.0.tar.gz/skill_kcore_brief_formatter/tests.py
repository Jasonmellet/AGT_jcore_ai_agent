from skill import format_brief
out = format_brief(["alpha", "", "beta"])
assert out == "- alpha\n- beta"
print("ok")
